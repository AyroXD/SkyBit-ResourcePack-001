SKYBIT RESOURCE PACK v3.7.0
Minecraft Java Edition 1.21.11
Resource Pack Format: 75

Visual Overhaul:
- kompletne nove material/pixel textury
- premium Legendary/Mythic crates
- 3D keys, crystals, gear a armor inventory models
- SkyBit AFK Zone Core model
- nove pack branding
